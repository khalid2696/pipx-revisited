function y=isempty(p)

y=((p.n*p.m)==0);