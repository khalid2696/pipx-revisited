function y=isscalar(f)

y=(f.n==1)&&(f.m==1);