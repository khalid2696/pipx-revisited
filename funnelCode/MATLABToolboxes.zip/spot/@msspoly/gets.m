function s=gets(p)
% function s=gets(p)
%
% get field s of mss polynomial p

% AM 09.01.09
s=p.s;