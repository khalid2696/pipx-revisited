function y=length(p)
% function y=length(p)
%
% total number of elements in p

% AM 10.01.09

y=p.n*p.m;