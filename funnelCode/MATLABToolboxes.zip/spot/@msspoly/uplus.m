function q=uplus(p)
%

% AM 09.01.09

q=p;