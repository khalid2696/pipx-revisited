function ltid_cg_test1(m,n)

if nargin<1, m=1100; end
if nargin<2, n=1000; end

A=sprandn(m,n,0.01);
B=randn(m,1);
q=@(x)(A'*(A*x));
f=A'*B;

tic;[x,i]=ltid_cg(q,f,1e-7);t=toc;e=norm(A*x-B);
tic;x1=A\B;t1=toc;e1=norm(A*x1-B);

fprintf('\n  cg: |Ax-B|=%f in %f sec (%d steps)  %f',e,t,i)
fprintf('\n  vs: |Ax-B|=%f in %f sec\n',e1,t1)
