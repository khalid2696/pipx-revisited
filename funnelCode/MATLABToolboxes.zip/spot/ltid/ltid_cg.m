function [x,k]=ltid_cg(q,f,r)
% function [x,k]=ltid_cg(q,f,r)
%
% conjugate gradient for solving Q*x=f, where Q=Q'>0 is given by q=@(x)Q*x,
% by minimizing J(x)=x'*Q*x-2*f'*x over the span of {f,Q*f,...,Q^{k-1}*f}
% producing suboptimal vectors x{k} (x{0}=0, x{1}=f*(f'*f/f'*Q*f), etc.)
% until |Q*x{k}-f|<r, or J(x{k+1})>J(x{k}), or k>n
% 
%
% INPUTS:
%   q  -  function handle: q=@(x)(Q*x) for n-by-1 double x
%   f  -  n-by-1 double
%   r  -  positive real: absolute tolerance (default 1e-8)
%
% OUTPUTS:
%   x  -  n-by-1 real, Q*x~f
%   k  -  number of Q evaluations performed

if nargin<2, error('3 inputs required'); end
if nargin<3, r=1e-8; end
if ~isa(q,'function_handle'), error('input 1 not a function handle'); end
if ~isa(f,'double'), error('input 2 not a double'); end
[n,nf]=size(f); if nf~=1, error('input 3 not a column'); end
r=double(r(1)); if r<=0, error('input 4 not positive'); end

% run x{k+1}=x{k}+a{k}*e{k}+b{k}*(x{k-1}-x{k}), where e{k}=f-Q*x{k},  
% i.e. e{k+1}=e{k}-a{k}*Q*e{k}-b{k}*(e{k}-e{k-1})
% where a{k},b{k} are chosen to make e{k+1} orthogonal to e{k} and e{k-1}
% initialize at x{0}=0, x{1}=f*(|f|^2/f'*Q*f)

k=0;                           % no Q evaluations yet
x=zeros(n,1);                  % initial guess at x
e=f;                           % initial value of e=f-Q*x
J=0;                           % initial value of J=2x'*f-x'*Q*x=x'*(f+e)
ee=e'*e;
if sqrt(ee)<r,  return; end    % x=0 is good enough
qe=q(e); k=1;                  % the first Q evaluation
eqe=e'*qe;                     % eqe=e'*Q*e
if eqe==0, return; end         % x=0 is good enough, after all
xo=x;                          % old x
eo=e;                          % old e
a=ee/eqe;                      % update coefficient
x=e*a;                         % new x
e=e-qe*a;                      % new e

while k<n,
    J1=x'*(f+e);
    if J1<J, return; end       % accuracy must be all messed up
    J=J1;
    ee=e'*e;                   % new e'*e
    if sqrt(ee)<r, return; end % current x is good enough
    qe=q(e); k=k+1;            % new evaluation of Q
    d=e-eo;                    % increment of e
    eqe=e'*qe;                 % find a,b to minimize |e-a*qe-b*d|
    qeqe=qe'*qe;
    dqe=d'*qe;
    ed=e'*d;
    dd=d'*d;
    if qeqe*dd<=dqe^2, return; end    % accuracy must be all messed up
    y=[qeqe dqe;dqe dd]\[eqe;ed];
    x1=x+e*y(1)+(xo-x)*y(2);
    e1=e-qe*y(1)-(e-eo)*y(2);
    xo=x;
    x=x1;
    eo=e;
    e=e1;
end
    
    
    
    
    
    
    