function x=ltid_LinfL1(A,B,r)
% function x=ltid_LinfL1(A,B,r)
%
% given  m-by-n real matrix A with m>n, m-by-1 real vector B, and r>0
% minimizes L1 norm of x subject to Linf norm of Ax-B being less than r

[m,n]=size(A);                % dimensions of A
x=msspoly('x',[n 1]);         % the actual decision vector
z=msspoly('z',[2*m 1]);       % slack variables
w=msspoly('w',[3*n 1]);       % slack variables
e=A*x-B;                      % fitting error 
pr=mssprog;                   % initialize mss program
pr.free=x;                    % x is free
pr.pos=z;                     % z>0
pr.pos=w;                     % w>0
pr.eq=r+e-z(1:m);             % r>-e 
pr.eq=r-e-z(m+1:2*m);         % y>e
pr.eq=w(n+1:2*n)+x-w(1:n);    % w(1:n)>x
pr.eq=w(2*n+1:3*n)-x-w(1:n);  % w(1:n)>-x
pr.sedumi=sum(w(1:n));        % minimize sum(w(1:n))
x=pr({x});                    % get the answer as a "double"