function [p,er]=ltid_symfit(f,r,m,n)
% function [p,er]=ltid_symfit(f,r,m,n)
%
% find best uniform polynomial approximation p of degree m
% on function f (must work point-wise on column vectors)
% using samples from linspace(r(1),r(2),n)

t=linspace(r(1),r(2),n)';                % argument samples
ft=f(t);                                 % samples of f
M=repmat(t,1,abs(m)).^repmat((abs(m)-1:-1:0),n,1);
if m>0,
    p=(M\ft)'; 
else
    p=ltid_Linf(M,ft)';
end
pt=polyval(p,t);                        % samples of p
er=max(abs(ft-pt));
fprintf('order=%d:  error = %e\n',abs(m)-1,er)
if nargout==0,
    close(gcf);
    subplot(2,1,1);plot(t,ft,t,pt);grid
    subplot(2,1,2);plot(t,ft-pt);grid
end
