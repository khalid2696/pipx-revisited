function y = sim_tpval( p,x )
% function y = sim_tpval( p,x )
%
% evaluate trigonometric polynomial p on a column of row vector arguments
 
m=size(x,1);
y=cos(acos(min(1,max(-1,(x-repmat(p.a,m,1))./repmat(p.b,m,1))))*p.d')*p.c;

end

