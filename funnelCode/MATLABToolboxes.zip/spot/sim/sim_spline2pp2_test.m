function sim_spline2pp2_test(m)
% function sim_spline2pp2_test(m)
% 
% testing sim_spline2pp2.m on [sin(t);...;sin(mt)] (10 breaks on [0,pi])

if nargin<1, m=2; end

t=linspace(0,pi,7);
p=spline(t,sin((1:m)'*t));
q=sim_spline2pp2(p);
x=linspace(0,pi,1000);
px=ppval(p,x);
qx=ppval(q,x);
close(gcf)
for i=1:m,
    subplot(m,1,i);plot(x,px(i,:),x,qx(i,:));grid
end

end

