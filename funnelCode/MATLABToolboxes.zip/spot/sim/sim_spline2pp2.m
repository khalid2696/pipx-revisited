function [ q ] = sim_spline2pp2( p )
% function [ q ] = sim_spline2pp2( p )
% 
% convert a spline p to second degree pp q

q=p;
q.order=3;
n=length(q.breaks);
m=q.dim;
t=q.breaks(2:n)-q.breaks(1:n-1);
tt=repmat(t,m,1);
tt=tt(:);
c=q.coefs;
q.coefs=[c(:,2)+1.5*c(:,1).*tt c(:,3)-0.5*c(:,1).*(tt.^2) c(:,4)];

end

