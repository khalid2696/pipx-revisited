function v=sim_cosm(y,d)
% function v=sim_cosm(y,d)
%
% convex smoothing of data vector y using depth d 
%
% INPUTS:
%   y  -  n-by-k real
%   d  -  positive integer 

v1=y;
v2=y;

