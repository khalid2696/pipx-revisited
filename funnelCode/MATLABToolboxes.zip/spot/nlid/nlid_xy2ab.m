function [a,b]=nlid_xy2ab(x,y,d)
% function [a,b]=nlid_xy2ab(x,y,d)
%
% INPUTS:
%    x  -  n-by-m real
%    y  -  n-by-1 real
%    d  -  k-by-m non-negative integer

if nargin<