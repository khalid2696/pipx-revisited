function [fun,coeff] = nlid_generate_basis(var,l,monom,arg)
    mn = monom(arg{:})';
    if size(mn,1) == 1, mn = repmat(mn,l,1);
    elseif size(mn,1) ~= l, error([var ' monomials size ' ...
                            'incorrect.']); 
    end
    coeff = reshape(msspoly(var,prod(size(mn))),size(mn,1),size(mn,2));
    fun = sum(coeff.*mn,2);
end