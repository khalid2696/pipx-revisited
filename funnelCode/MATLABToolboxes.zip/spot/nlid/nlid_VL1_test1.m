function nlid_VL1_test1(n,m)
%  function nlid_VL1_test1(n,m)
%
%  test nlid_VL1.m on n samples of
%  v=y+t*(u-0.5-sin(2*y))
%  (y random on (-1,1), u random on (0,1), t random on [0.01,0.02])

if nargin<1, n=100; end
if nargin<2, m=5; end

y=2*rand(n,1)-1;
t=0.01*(1+rand(n,1));
u=rand(n,1)-0.5;
v=y+t.*(0.3*u-sin(2.5*y));
w=[t t.*u];

[E,H]=nlid_VL1(v,y,w,m);

mty=(1:m)'*asin(y)';
mtv=(1:m)'*asin(v)';
Sy=[ones(1,n);sin(mty)];
Sv=[ones(1,n);sin(mtv)];
ey=E*Sy;
ev=E*Sv;
hyw=sum(w'.*(H*Sy),1);
close(gcf);
subplot(2,1,1);plot(y,ey,'.');grid
subplot(2,1,2);plot(ey-ev,hyw,'.');grid

end

