function [E,H] = nlid_VL1(v,y,w,m)
%  function [E,H] = nlid_VL1(v,y,t,w,m)
%  
%  given n-by-1 real v,y in the (-1,1) range, n-by-k real w, integer m>0,
%  find 1-by-(m+1) real E and k-by-(m+1) real F to minimize the sum of
%  |e(v)-e(y)+h(y,w)|^2*[1/h'(y,w)+1/{2e'(y)-h'(y,w)}] 
%  subject to e(-1)=-1, e(1)=1, h'(y,w)>0,  2e'(y)>h'(y,w)
%  where e(Y)=E*S(Y), h(Y,W)=W'*H*S(Y), 
%  S(y)=[1;sin(asin(y));...;sin(m*asin(y))]

if max(abs(v))>=1, error('input 1: not in (-1,1)'); end
if max(abs(y))>=1, error('input 2: not in (-1,1)'); end
v=v(:);
y=y(:);
[n,k]=size(w);
if length(v)~=n, error('inputs 1,3: not compatible'); end
if length(y)~=n, error('inputs 1,2: not compatible'); end

mty=(1:m)'*asin(y)';
mtv=(1:m)'*asin(v)';
Sy=[ones(1,n);sin(mty)];
Dy=[zeros(1,n);cos(mty).*((1:m)'*(1./sqrt(1-y.^2))')];
Sv=[ones(1,n);sin(mtv)];
S0=[1;sin((1:m)'*asin(-1))];
S1=[1;sin((1:m)'*asin(1))];

E=msspoly('E',m+1)';    % E,H are decision variables
H=reshape(msspoly('H',k*(m+1)),k,m+1);
ey=E*Sy;                % row of e(y) samples
e0=E*S0;                % e(-1)
e1=E*S1;                % e(1)
ev=E*Sv;                % row of e(v) samples
hyw=sum(w'.*(H*Sy),1);  % row of h(y,w) samples
Ey=E*Dy;                % row of de/dy samples 
Hyw=sum(w'.*(H*Dy),1);  % row of dh/dy samples 
r=ev-ey+hyw;            % row of e(v)-e(y)-h(y,w) samples
x=reshape(msspoly('x',3*n),3,n);    % x,y are slack variables
y=reshape(msspoly('y',3*n),3,n);

pr=mssprog;
pr.free=E;
pr.free=H;
pr.psd=x;                  % x(1,i)>x(2,i)^2/x(3,i)
pr.eq=e0+1;                % e(-1)=-1
pr.eq=e1-1;                % e(1)=1
pr.eq=x(2,:)-r;
pr.eq=x(3,:)-Hyw;
pr.psd=y;                  %  y(1,i)>y(2,i)^2/y(3,i)
pr.eq=y(2,:)-r;
pr.eq=y(3,:)-2*Ey+Hyw;
pr.sedumi=sum(x(1,:))+sum(y(1,:));
x=pr({x});
y=pr({y});
E=pr({E});
H=pr({H});

end

