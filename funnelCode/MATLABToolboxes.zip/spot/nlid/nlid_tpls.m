function [v,p]=nlid_tpls(x,y,d,r)
% function [v,p]=nlid_tpls(x,y,d,r)
%
% INPUTS:
%   x  -  m-by-n real: rows are input samples
%   y  -  m-by-k real: rows are output samples
%   d  -  1-by-n positive integer: maximal degrees, variable-wise
%   r  -  real, non-negative: expansion coefficient (default r=0)
%
% OUTPUT:
%   v  -  m-by-k real: fitted values of y
%   p  -  trigonometric polynomial (see "sim_tpval.m" for evaluation)

if nargin<3, error('3 inputs required'); end
if nargin<4, r=0; end
r=max(real(r(1)),0);
x=real(double(x));
y=real(double(y));
d=max(1,round(real(double(d(1,:)))));
[m,n]=size(x);
if m~=size(y,1), error('inputs 1,2 incompatible'); end
if n~=length(d), error('inputs 1,3 incompatible'); end
p.a=(max(x,[],1)+min(x,[],1))/2;
p.b=(1+r)*max(abs(x-repmat(p.a,m,1)),[],1); 
p.b(p.b==0)=1;
p.d=mint_ch(mint_down(d));
p.c=cos(acos((x-repmat(p.a,m,1))./repmat(p.b,m,1))*p.d')\y;
v=sim_tpval(p,x);
